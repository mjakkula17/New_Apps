//
//  ViewController.swift
//  subject_display
//
//  Created by Mounika Jakkula on 10/3/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


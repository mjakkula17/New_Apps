//
//  ResultViewController.swift
//  practice_bmi
//
//  Created by Mounika Jakkula on 11/14/23.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var displayweightOL: UILabel!
    
    
    @IBOutlet weak var displayheightOL: UILabel!
    
    
    @IBOutlet weak var displayBMI: UILabel!
    
    
    @IBOutlet weak var displayimage: UIImageView!
    
    var weight = ""
    var height = ""
    var bmi = 0.0
    var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        displayweightOL.text! += weight
        displayheightOL.text! += height
        displayBMI.text! += String(bmi)
        displayimage.image = UIImage(named: imageName)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

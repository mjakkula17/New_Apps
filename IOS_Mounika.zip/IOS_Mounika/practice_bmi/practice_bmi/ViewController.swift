//
//  ViewController.swift
//  practice_bmi
//
//  Created by Mounika Jakkula on 11/14/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var weightOL: UITextField!
    
    @IBOutlet weak var HeightOL: UITextField!
    
    var bmi = 0.0
    var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    
    
    @IBAction func CheckBmiBtn(_ sender: UIButton) {
        
        var weight = Double(weightOL.text!)
        var height = Double(HeightOL.text!)
        
        var val = weight! / (height! * height!)
        bmi = val * 703
        
        if bmi <= 18.4 {
            imageName = "underweight"
        }
        else if bmi>=18.5 && bmi<=24.9{
            imageName = "normal"
        }
        else if bmi>=25 && bmi<=39.9{
            imageName = "overweight"
        }
        else{
            imageName = "obesity"
        }
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //create a variable called transition
        var transition = segue.identifier
        
        if transition == "Result1" {
            var destination = segue.destination as! ResultViewController
            
            destination.weight = weightOL.text!
            destination.height = HeightOL.text!
            destination.bmi = bmi
            destination.imageName = imageName
            
            
            //destination.weight = weightOL.text!
        }
    }
    
}

//
//  ContactViewController.swift
//  contact_practice
//
//  Created by Mounika Jakkula on 11/29/23.
//

import UIKit

class ContactViewController: UIViewController {
    
    var nme1 = ""
    var number = ""

    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var contact: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        name.text = "\(nme1)"
        contact.text = "\(number)"
        print(number)

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

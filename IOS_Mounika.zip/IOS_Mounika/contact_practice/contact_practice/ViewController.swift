//
//  ViewController.swift
//  contact_practice
//
//  Created by Mounika Jakkula on 11/29/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return words.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableviewOL.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        //populate the cell
        cell.textLabel?.text = words[indexPath.row][0]
        //return the cell
        return cell
    }
    
    
    var words  = [["Mounika Jakkula🤗","6605280909"],["Micheal😒","6605280808"],["Mahesh🧐","6600707563"],["John🫢","6605347070"],["joy","6607896060"]]
    

    @IBOutlet weak var tableviewOL: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableviewOL.delegate = self
        tableviewOL.dataSource = self
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(transition == "result"){
            let destination = segue.destination as!
            ContactViewController
            destination.nme1 = words[(tableviewOL.indexPathForSelectedRow?.row)!][0]
            destination.number = words[(tableviewOL.indexPathForSelectedRow?.row)!][1]


        }
    }


}


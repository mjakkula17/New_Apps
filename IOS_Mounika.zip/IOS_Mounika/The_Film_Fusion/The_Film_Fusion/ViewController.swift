//
//  ViewController.swift
//  The_Film_Fusion
//
//  Created by Mounika Jakkula on 12/3/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        imageOL.image = UIImage(named: "film fusion")
    }


    @IBAction func getstartedBtn(_ sender: UIButton) {
    }
}


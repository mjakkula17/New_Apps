//
//  MovieDetailsViewController.swift
//  The_Film_Fusion
//
//  Created by Mounika Jakkula on 12/3/23.
//

import UIKit

class MovieDetailsViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies_Array[0].movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell = movieCollectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        cell.assignMovie(with: (mov!.movies[indexPath.row]))
             return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        movieCastLabel.isHidden = false
        moviePlotLabel.isHidden = false
        //movieYearLabel.isHidden = false
        movieRatingLabel.isHidden = false
        movieNameLabel.isHidden = false
        movieBoxOfficeLabel.isHidden = false
           assignMovieDetails(index: indexPath)
       }
    func assignMovieDetails(index: IndexPath){
        movieNameLabel.text! = "Movie Name: \(mov!.movies[index.row].title)"
        movieRatingLabel.text! = "Movie Rating: \(mov!.movies[index.row].movieRating)"
        movieBoxOfficeLabel.text! = "Box Office Collection: \(mov!.movies[index.row].boxOffice)"
        //movieYearLabel.text! = "Movie Released Year: \(mov!.movies[index.row].releasedYear)"
        moviePlotLabel.text! = "Movie Plot: \(mov!.movies[index.row].moviePlot)"
        movieCastLabel.text! = "Cast: \n\(mov!.movies[index.row].cast.formatted())"
    }
    
    

    @IBOutlet weak var movieCollectionView: UICollectionView!
    
   
    @IBOutlet weak var movieNameLabel: UILabel!
    

    @IBOutlet weak var movieRatingLabel: UILabel!
    
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    
    
    @IBOutlet weak var movieCastLabel: UILabel!
    
    @IBOutlet weak var moviePlotLabel: UILabel!
    
    var mov : Genre?
    var num : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        movieCollectionView.delegate = self
        movieCollectionView.dataSource = self
        self.title = mov!.category
        movieCastLabel.isHidden = true
        moviePlotLabel.isHidden = true
        //movieYearLabel.isHidden = true
        movieRatingLabel.isHidden = true
        movieNameLabel.isHidden = true
        movieBoxOfficeLabel.isHidden = true
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

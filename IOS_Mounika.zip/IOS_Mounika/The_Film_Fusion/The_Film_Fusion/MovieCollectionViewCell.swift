//
//  MovieCollectionViewCell.swift
//  The_Film_Fusion
//
//  Created by Mounika Jakkula on 12/3/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    func assignMovie(with m: Movie){
        imageViewOutlet.image = m.image
    }
}

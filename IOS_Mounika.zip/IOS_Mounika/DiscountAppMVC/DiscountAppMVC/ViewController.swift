//
//  ViewController.swift
//  DiscountAppMVC
//
//  Created by Mounika Jakkula on 10/31/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var amountOL: UITextField!
    
    @IBOutlet weak var discntRateOL: UITextField!
    var priceAfterDiscount = 0.0
    var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func calcBtn(_ sender: UIButton) {
        //Read the amount from OL
        var amount = Double(amountOL.text!)
        
        //Read the discount rate from OL
        var discntRate = Double(discntRateOL.text!)
        
        
        priceAfterDiscount = amount! - (amount!*discntRate!/100)
        if(discntRate! > 0.0)
        {
            imageName = "discount"
        }
        else{
            imageName = "nodiscount"
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        if transition == "resultsegue"{
            
            var destination = segue.destination as! RVCViewController
            destination.amount = amountOL.text!
            destination.discntRate = discntRateOL.text!
            destination.priceAfterDiscount = priceAfterDiscount
            destination.imageName = imageName
            
            
        }
        
    }
    

}


//
//  RVCViewController.swift
//  DiscountAppMVC
//
//  Created by Mounika Jakkula on 10/31/23.
//

import UIKit

class RVCViewController: UIViewController {

    @IBOutlet weak var displayAmountOL: UILabel!
    
    @IBOutlet weak var displayDiscntRateOL: UILabel!
    
    @IBOutlet weak var displayPriceAfterDiscntOL: UILabel!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    var amount = ""
    var discntRate = ""
    var priceAfterDiscount = 0.0
    var imageName = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        displayAmountOL.text! += amount
        displayDiscntRateOL.text! += discntRate
        displayPriceAfterDiscntOL.text! += String(priceAfterDiscount)
        displayImage.image = UIImage(named: imageName)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

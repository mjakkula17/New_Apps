//
//  RVCViewController.swift
//  BMIAppMVC
//
//  Created by Mounika Jakkula on 11/2/23.
//

import UIKit

class RVCViewController: UIViewController {

    
    @IBOutlet weak var displayWeigth: UILabel!
    
    @IBOutlet weak var displayHeight: UILabel!
    
    @IBOutlet weak var displayBMI: UILabel!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    var BMI = 0.0
    var imageName = ""
    var weigth = ""
    var height = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        displayWeigth.text = displayWeigth.text! + weigth
        
        displayHeight.text = displayHeight.text! + height
        
        //displayBMI.text! += String(BMI)
        displayBMI.text = displayBMI.text! + String(BMI)
        displayImage.image = UIImage(named: imageName)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

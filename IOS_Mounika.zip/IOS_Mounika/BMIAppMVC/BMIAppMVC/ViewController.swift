//
//  ViewController.swift
//  BMIAppMVC
//
//  Created by Mounika Jakkula on 11/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var weigthOL: UITextField!
    
    
    @IBOutlet weak var HeigthOL: UITextField!
    
    var BMI = 0.0
    var imageName = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func calculateBtn(_ sender: UIButton) {
        //Read the weigth from OL
        var weigth = Double(weigthOL.text!)
        
        //Read the height from OL
        var height = Double(HeigthOL.text!)
        var val1 = (weigth! / (height!*height!))
                    
        BMI = val1 * 703
        
        if(BMI <= 18.4)
        {
            imageName = "underweight"
        }
        else if(BMI >= 18.5 && BMI <= 24.9)
        {
            imageName = "normalweight"
        }
        else if(BMI >= 25.0 && BMI <= 39.9)
        {
            imageName = "overweight"
        }
        else if(BMI >= 40)
        {
            imageName = "obese"
        }
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        if transition == "resultsegue"{
            
            var destination = segue.destination as! RVCViewController
            destination.weigth = weigthOL.text!
            destination.weigth = HeigthOL.text!
            destination.BMI = BMI
            
            destination.imageName = imageName
            
        }
        
        
    }
    
}

//
//  ViewController.swift
//  Jakkula_UniversityApp
//
//  Created by Mounika Jakkula on 11/16/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return univArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = universitiesTableView.dequeueReusableCell(withIdentifier:  "domainCell", for: indexPath)
                
                cell.textLabel?.text = univArray[indexPath.row].domain
        
                return cell
    }
    
    var univArray = universities
   

    @IBOutlet weak var universitiesTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Domains"
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                let transition = segue.identifier
                if transition == "listsSegue"{
                    let destination = segue.destination as! UniversityListViewController
                    
                    destination.Univlist = univArray[(universitiesTableView.indexPathForSelectedRow?.row)!]
                }
    }

    
}


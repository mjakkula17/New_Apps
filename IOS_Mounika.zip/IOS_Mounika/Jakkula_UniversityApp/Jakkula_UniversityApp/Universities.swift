//
//  Universities.swift
//  Jakkula_UniversityApp
//
//  Created by Mounika Jakkula on 11/16/23.
//

import Foundation

struct UniversityList{
    var collegeName = " "
    var collegeImage = ""
    var collegeInfo = ""
    
}
struct Universities {
    var domain = ""
    var list_Array :[UniversityList] = []
    
}


let univ1 = Universities(domain:"Computer Science",
                        list_Array :[
                            UniversityList(collegeName:"NJIT",collegeImage:"NJIT",collegeInfo: "NJIT has the largest college of engineering, computing, architecture, and design, and is home to the largest technology and life science business incubator in the state. NJIT has research expenditures of over $140 million."),
                            UniversityList(collegeName:"Arizona State University",collegeImage:"arizona",collegeInfo: "Arizona State University is a public institution that was founded in 1885. It has a total undergraduate enrollment of 65,492 (fall 2022), its setting is urban, and the campus size is 2,006 acres. It utilizes a semester-based academic calendar."),
                            UniversityList(collegeName:"Harvard University ",collegeImage:"harvard",collegeInfo: "Harvard is a founding member of the Association of American Universities and a preeminent research university with very high research activity (R1) and comprehensive doctoral programs across the arts, sciences, engineering, and medicine ."),
                            UniversityList(collegeName:"George Mason University",collegeImage:"george",collegeInfo: "Mason is among the top ten in research growth among U.S. public universities, according to the National Science Foundation. The organization FIRE ranks Mason in the top 20 nationally among public institutions for welcoming and fostering free speech."),
                            UniversityList(collegeName:"Northwest Missouri State Univeristy ",collegeImage:"nwmsu",collegeInfo: "This public research university is recognized nationally and internationally for the quality of its faculty, students, research and community leadership. The university offers some type of financial aid o 64% of it students in order to help them continue their educaiton."),
                     ]
                        
)
                        

let univ2 = Universities(domain:"Machine learning",
                        list_Array :[
                        UniversityList(collegeName:"Michigan State University",collegeImage:"michigan",collegeInfo: "Michigan State University is the nation's premier land-grant university and one of the top research universities in the world."),
                        UniversityList(collegeName:"NYU",collegeImage:"NYU",collegeInfo: "The University has degree-granting campuses in New York, Abu Dhabi, and Shanghai and operates 12 global academic centers and research programs"),
                        UniversityList(collegeName:"Saint Louis University",collegeImage:"saint",collegeInfo: "Top-ranked Saint Louis University offers 80+ undergraduate and graduate disciplines. Learn about SLU's academic excellence"),
                        UniversityList(collegeName:"University of Texas at Dallas",collegeImage:"utd",collegeInfo: "The University of Texas at Dallas is a public institution that was founded in 1969.The University of Dallas has established reputation with more than 15,000 alumni from over 96 countries."),
                        UniversityList(collegeName:"University of Missouri Kansas city",collegeImage:"umkc",collegeInfo: "This public research university is recognized nationally and internationally for the quality of its faculty, students, research and community leadership. The university offers some type of financial aid o 64% of it students.")
                     ]
                        
)
                       
let univ3 = Universities(domain:"Data Science",
                        list_Array :[
                            UniversityList(collegeName:"NJIT",collegeImage:"NJIT",collegeInfo: "NJIT has the largest college of engineering, computing, architecture, and design, and is home to the largest technology and life science business incubator in the state. NJIT has research expenditures of over $140 million."),
                            UniversityList(collegeName:"Northwest Missouri State Univeristy ",collegeImage:"nwmsu",collegeInfo: "Northwest Missouri State University is a public institution that was founded in 1905. It has a total undergraduate enrollment of 5,308 (fall 2022), its setting is rural, and the campus size is 370 acres. It utilizes a semester-based academic calendar."),
                            UniversityList(collegeName:"University of Missouri Kansas city",collegeImage:"umkc",collegeInfo: "This public research university is recognized nationally and internationally for the quality of its faculty, students, research and community leadership. The university offers some type of financial aid o 64% of it students."),
                            UniversityList(collegeName:"Arizona State University",collegeImage:"arizona",collegeInfo: "Arizona State University is a public institution that was founded in 1885. It has a total undergraduate enrollment of 65,492 (fall 2022), its setting is urban, and the campus size is 2,006 acres. It utilizes a semester-based academic calendar."),
                            UniversityList(collegeName:"Harvard University ",collegeImage:"harvard",collegeInfo: "Harvard is a founding member of the Association of American Universities and a preeminent research university with very high research activity (R1) and comprehensive doctoral programs across the arts, sciences, engineering, and medicine."),
                        ]
)

let univ4 = Universities(domain:"IT",
                        list_Array :[
                            UniversityList(collegeName:"George Mason University",collegeImage:"george",collegeInfo: "Mason is among the top ten in research growth among U.S. public universities, according to the National Science Foundation. The organization FIRE ranks Mason in the top 20 nationally among public institutions for welcoming and fostering free speech."),
                            UniversityList(collegeName:"NYU",collegeImage:"NYU",collegeInfo: "The University has degree-granting campuses in New York, Abu Dhabi, and Shanghai and operates 12 global academic centers and research programs"),
                            UniversityList(collegeName:"Michigan State University",collegeImage:"michigan",collegeInfo: "Michigan State University is the nation's premier land-grant university and one of the top research universities in the world. "),
                            UniversityList(collegeName:"Saint Louis University",collegeImage:"saint",collegeInfo: "Top-ranked Saint Louis University offers 80+ undergraduate and graduate disciplines. Learn about SLU's academic excellence"),
                            UniversityList(collegeName:"University of Texas at Dallas",collegeImage:"utd",collegeInfo: "The University of Texas at Dallas is a public institution that was founded in 1969.The University of Dallas has established reputation with more than 15,000 alumni from over 96 countries."),
                        ]
)

let univ5 = Universities(domain:"Cyber Security",
                        list_Array :[
                        UniversityList(collegeName:"Northwest Missouri State Univeristy ",collegeImage:"nwmsu",collegeInfo: "This public research university is recognized nationally and internationally for the quality of its faculty, students, research and community leadership. The university offers some type of financial aid o 64% of it students in order to help them continue their educaiton."),
                        UniversityList(collegeName:"University of Texas at Dallas",collegeImage:"utd",collegeInfo: "The University of Texas at Dallas is a public institution that was founded in 1969.The University of Dallas has established reputation with more than 15,000 alumni from over 96 countries."),
                        UniversityList(collegeName:"Saint Louis University",collegeImage:"saint",collegeInfo: "Top-ranked Saint Louis University offers 80+ undergraduate and graduate disciplines. Learn about SLU's academic excellence"),
                        UniversityList(collegeName:"George Mason University",collegeImage:"george",collegeInfo: "Mason is among the top ten in research growth among U.S. public universities, according to the National Science Foundation. The organization FIRE ranks Mason in the top 20 nationally among public institutions for welcoming and fostering free speech."),
                        UniversityList(collegeName:"Arizona State University",collegeImage:"arizona",collegeInfo: "Arizona State University is a public institution that was founded in 1885. It has a total undergraduate enrollment of 65,492 (fall 2022), its setting is urban, and the campus size is 2,006 acres. It utilizes a semester-based academic calendar."),
                     ]
                        
)


let universities = [univ1,univ2,univ3,univ4,univ5]



//
//  UniversityInfoViewController.swift
//  Jakkula_UniversityApp
//
//  Created by Mounika Jakkula on 11/16/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    var UnivrDetail = UniversityList()

    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.title = UnivrDetail.collegeName
        universityInfoOutlet.text = UnivrDetail.collegeInfo
        universityInfoOutlet.isHidden = true
        universityImageViewOutlet.image = UIImage(named: UnivrDetail.collegeImage)
        universityImageViewOutlet.frame.origin.x = view.frame.maxX
        
        UIView.animate(withDuration: 1,delay:0.6, animations: {
            self.universityImageViewOutlet.center.x = self.view.center.x
    
        })
    }
    
    
    @IBAction func showInfoAction(_ sender: UIButton) {
        universityInfoOutlet.isHidden = false
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

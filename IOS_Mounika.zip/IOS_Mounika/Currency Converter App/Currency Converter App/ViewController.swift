//
//  ViewController.swift
//  Currency Converter App
//
//  Created by Mounika Jakkula on 10/4/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var ImageDisplay: UIImageView!
    
    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var outputOL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ImageDisplay.image = UIImage(named: "default.jpeg")
    }
    
    @IBAction func USDbtn(_ sender: Any) {
        //ImageDisplay.image = UIImage(named: "usd.jpeg")
        
        var amount:Double = 0.0
        amount = Double(inputOL.text!)!
        if(amount == 0){
            ImageDisplay.image = UIImage(named: "oops.jpeg")
            outputOL.text! = "₹ 0.0 Oops! cannot convert"
        }
        else if(amount.isNaN){
            ImageDisplay.image = UIImage(named: "oops.jpeg")
            outputOL.text! = "₹ 0.0 Oops! cannot convert"
        }
        else{
            ImageDisplay.image = UIImage(named: "usd.jpeg")
            var val1 = String(format: "%.2f",Double(amount) / 82.93)
            //outputOL.text! = String(format: "%.2f",Double(amount) / 82.93)
            var val2 = String(inputOL.text!)
            outputOL.text! = "\(val2) in usd is: $ \(val1)"
            
        }
    }
        
        @IBAction func CADbtn(_ sender: Any) {
            
            //ImageDisplay.image = UIImage(named: "cad.jpeg")
            
            var amount:Double = 0.0
            amount = Double(inputOL.text!)!
            
            if(amount == 0){
                ImageDisplay.image = UIImage(named: "oops.jpeg")
                outputOL.text! = "₹ 0.0 Oops! cannot convert"
            }
            else{
                ImageDisplay.image = UIImage(named: "cad.jpeg")
                
                var val3 = String(format: "%.2f",Double(amount) / 82.93 * 1.26)
                var val4 = String(inputOL.text!)
                outputOL.text! = "\(val4) in cad is $ \(val3)"
                //outputOL.text! = String(format: "%.2f",Double(amount) / 82.93 * 1.26)
            }
            
        }
        
        
    }
    


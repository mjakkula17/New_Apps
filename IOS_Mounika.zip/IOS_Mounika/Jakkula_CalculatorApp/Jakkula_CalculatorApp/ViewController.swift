//
//  ViewController.swift
//  Jakkula_CalculatorApp
//
//  Created by Mounika Jakkula on 9/19/23.
//

import UIKit

class ViewController: UIViewController {
    //declaring the variables
    var firstnum = ""
    var secndnum = ""
    var valentered = ""
    var caloperator = ""
    var res:Double = 0.0
    
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func ACbtnclicked(_ sender: UIButton) {
        //AC button function
        firstnum = ""
        secndnum = ""
        valentered = ""
        caloperator = ""
        res = 0.0
        resultOutlet.text! = "Clear everything"
        
    }
    

    @IBAction func CBtnClicked(_ sender: UIButton) {
        //C button function
        if(!valentered.isEmpty)
        {
            valentered.removeLast()
            resultOutlet.text! = valentered
        }
    }
    
    @IBAction func PlusorMinusBtnclicked(_ sender: UIButton) {
        ////Plus or Minus button function
        if caloperator == "+"
        {
            caloperator = "-"
        }
        else if caloperator == "-"
        {
            caloperator = "+"
        }
    }
    
    @IBAction func ButtonDevision(_ sender: UIButton) {
        caloperator = "÷"
        firstnum = valentered
        valentered = ""
        
    }
    
    @IBAction func ButtonSeven(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "7"
        resultOutlet.text! += valentered
    }
    
    @IBAction func ButtonEight(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "8"
        resultOutlet.text! += valentered

    }
    
    
    @IBAction func ButtonNine(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "9"
        resultOutlet.text! += valentered

    }
    
    @IBAction func ButtonMultiply(_ sender: UIButton) {
        caloperator = "x"
        firstnum = valentered
        valentered = ""
        
    }
    
    @IBAction func ButtonFour(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "4"
        resultOutlet.text! += valentered

    }
    
    
    @IBAction func ButtonFive(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "5"
        resultOutlet.text! += valentered

    }
    
    
    @IBAction func ButtonSix(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "6"
        resultOutlet.text! += valentered

    }
    
    
    @IBAction func ButtonMinus(_ sender: UIButton) {
        caloperator = "-"
        firstnum = valentered
        valentered = ""
        
    }
   
    @IBAction func ButtonOne(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "1"
        resultOutlet.text! += valentered

        
    }
    
    
    @IBAction func ButtonTwo(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "2"
        resultOutlet.text! += valentered

    }
    
    
    @IBAction func ButtonThree(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "3"
        resultOutlet.text! += valentered

    }
    
    
    @IBAction func ButtonPlus(_ sender: UIButton) {
        caloperator = "+"
        firstnum = valentered
        valentered = ""
        
    }
    
    @IBAction func ButtonZero(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "0"
        resultOutlet.text! += valentered

        
    }
    
    @IBAction func ButtonDecimal(_ sender: UIButton) {
        resultOutlet.text! = ""
        valentered += "."
        resultOutlet.text! += valentered

    }
    
    @IBAction func ButtonModulo(_ sender: UIButton) {
        caloperator = "%"
        firstnum = valentered
        valentered = ""
        
    }
    
    @IBAction func ButtonEqualsto(_ sender: UIButton) {
        
       
        
        resultOutlet.text! = "="
        secndnum = valentered
        var Inputfirst:Double = 0.0
        var Inputscnd:Double = 0.0
        Inputfirst = Double(firstnum)!
        Inputscnd = Double(secndnum)!
        
        if(caloperator == "x")
        {
            resultOutlet.text! = String(Int(Inputfirst) * Int(Inputscnd))
        }
        else if(caloperator == "+")
        {
            var val3:Double = Inputfirst + Inputscnd
            if(String(val3).contains(".0"))
            {
                resultOutlet.text! = String(format: "%.0f", val3)
            }
            else{
                resultOutlet.text! = String(format: "%.2f", val3)
                //resultOutlet.text! = resultOutlet.text! + " \(val3)"
            }
        }
        else if(caloperator == "-")
        {
            resultOutlet.text! = String(Int(Inputfirst) - Int(Inputscnd))
        }
        else if(caloperator == "÷")
        {
            if(Inputscnd == 0){
                resultOutlet.text! = "Not a number"
            }
            else{
                var val:Double = Inputfirst / Inputscnd
                resultOutlet.text! = String(format: "%.5f", val)
            }
        }
        else
        {
            var val2:Double = Inputfirst.truncatingRemainder(dividingBy: Inputscnd)
            resultOutlet.text! = String(format: "%.1f", val2)
        }
        
        
    }
    

    
}


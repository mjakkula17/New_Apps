//
//  ResultViewController.swift
//  Jakkula_Exam02
//
//  Created by Mounika Jakkula on 11/14/23.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var displayLoanType: UILabel!
    
    @IBOutlet weak var displayLoanAmount: UILabel!
    
    
    @IBOutlet weak var displayInterestRate: UILabel!
    
    
    @IBOutlet weak var displayEMI: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    var loanType = ""
    var term = 0.0
    var interestRate = 0.0
    var loanAmount:Double = 0.0
    var imageName = ""
    var monthlyEMIPayment = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayLoanType.text! += loanType
        displayLoanAmount.text! += String(loanAmount)
        displayInterestRate.text! += String(interestRate)
        displayEMI.text! += String(monthlyEMIPayment)
        displayImage.image = UIImage(named: imageName)
        
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

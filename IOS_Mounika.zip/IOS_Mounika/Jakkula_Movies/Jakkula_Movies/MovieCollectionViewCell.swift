//
//  MovieCollectionViewCell.swift
//  Jakkula_Movies
//
//  Created by Mounika Jakkula on 11/27/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    
    func assignMovie(with mv: Movie){
            imageViewOutlet.image = mv.image
        
    }
}

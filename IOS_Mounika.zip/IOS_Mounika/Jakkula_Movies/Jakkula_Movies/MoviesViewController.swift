//
//  MoviesViewController.swift
//  Jakkula_Movies
//
//  Created by Mounika Jakkula on 11/27/23.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movis_Array[0].movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = movieCollectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        cell.assignMovie(with: (movi!.movies[indexPath.row]))
             return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        movieCastLabel.isHidden = false
        moviePlotLabel.isHidden = false
        movieYearLabel.isHidden = false
        movieRatingLabel.isHidden = false
        movieNameLabel.isHidden = false
        movieBoxOfficeLabel.isHidden = false
           assignMovieDetails(index: indexPath)
       }
    func assignMovieDetails(index: IndexPath){
        movieNameLabel.text! = "Movie Name: \(movi!.movies[index.row].title)"
        movieRatingLabel.text! = "Movie Rating: \(movi!.movies[index.row].movieRating)"
        movieBoxOfficeLabel.text! = "Box Office Collection: \(movi!.movies[index.row].boxOffice)"
        movieYearLabel.text! = "Movie Released Year: \(movi!.movies[index.row].releasedYear)"
        moviePlotLabel.text! = "Movie Plot: \(movi!.movies[index.row].moviePlot)"
        movieCastLabel.text! = "Cast: \n\(movi!.movies[index.row].cast.formatted())"
    }
    
    
    
    
    @IBOutlet weak var movieCollectionView: UICollectionView!
    
    @IBOutlet weak var movieNameLabel: UILabel!
    
    
    @IBOutlet weak var movieRatingLabel: UILabel!
    
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    
    
    @IBOutlet weak var movieYearLabel: UILabel!
    
    @IBOutlet weak var moviePlotLabel: UILabel!
    
    @IBOutlet weak var movieCastLabel: UILabel!
    
    
    var movi : Genre?
    var num : Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        movieCollectionView.delegate = self
        movieCollectionView.dataSource = self
        self.title = movi!.category
        movieCastLabel.isHidden = true
        moviePlotLabel.isHidden = true
        movieYearLabel.isHidden = true
        movieRatingLabel.isHidden = true
        movieNameLabel.isHidden = true
        movieBoxOfficeLabel.isHidden = true
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

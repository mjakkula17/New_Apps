import UIKit

var greeting = "Hello, playground"

print("hi",10)



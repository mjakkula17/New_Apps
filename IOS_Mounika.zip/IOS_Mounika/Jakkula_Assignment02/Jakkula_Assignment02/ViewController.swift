//
//  ViewController.swift
//  Jakkula_Assignment02
//
//  Created by Mounika Jakkula on 9/13/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitBTN(_ sender: Any) {
        //reading the values name, billAmount, tipPercentage from the text field
        if let name = nameOutlet.text, let billamnt = billAmountOutlet.text, let tippercent = tipPercentageOutlet.text {
            //converting the billAmount and tipPercentage to Double
                    if let BillAmount = Double(billamnt), let TipPercentage = Double(tippercent) {
                        //calculating the tipAmount and totalAmount
                        let TipAmount = (BillAmount * TipPercentage) / 100
                        let TotalAmount = BillAmount + TipAmount
                        //printing the output
                        nameLabel.text = "Name: \(name)"
                        billAmountLabel.text = String(format: "Bill Amount: $%.2f", BillAmount)
                        tipAmountLabel.text = String(format: "Tip Amount: $%.2f", TipAmount)
                        totalAmountLabel.text = String(format: "Total Amount: $%.2f", TotalAmount)
                    }
                }

    }
    
    @IBAction func ResetBTN(_ sender: Any) {
        
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
                
        nameLabel.text = ""
        billAmountLabel.text = ""
        tipAmountLabel.text = ""
        totalAmountLabel.text = ""

    }
    
}


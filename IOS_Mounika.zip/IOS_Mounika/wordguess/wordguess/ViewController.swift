//
//  ViewController.swift
//  wordguess
//
//  Created by Mounika Jakkula on 10/10/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var DisplayLabel: UILabel!
    
    @IBOutlet weak var HintLabel: UILabel!
    
    @IBOutlet weak var letterEntered: UITextField!
    
    @IBOutlet weak var checkBtn: UIButton!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var playagainBtn: UIButton!
    
    var words = [["SWIFT","programming language"], ["CRICKET","game"],["MACBOOK","Apple"],["CYCLE","Two wheeler"]]
    
    var count = 0;
    var word = ""
    var lettersGuessed = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //disabling the check button
        checkBtn.isEnabled = false
        
        //we are getting first word from array
        word = words[count][0]
        
        HintLabel.text = "Hint: " + words[count][1]
        statusLabel.text = ""
        
        
    }
    
    @IBAction func checkBtnClicked(_ sender: Any) {
        
        var letter = letterEntered.text!
        lettersGuessed = lettersGuessed+letter
        var revealedWord = ""
        
                for l in word{
                    if lettersGuessed.contains(l){
                        revealedWord += "\(l)"
                    }
                    else{
                        revealedWord += "_ "
                    }
                }
        DisplayLabel.text = revealedWord
                letterEntered.text = ""
                
                //If the word is guessed correctly, we are enabling play again button and disabling the check button.
                if DisplayLabel.text!.contains("_") == false{
                    playagainBtn.isHidden = false;
                    checkBtn.isEnabled = false;
                }
                checkBtn.isEnabled = false
    }

    
    @IBAction func playagainBtnClicked(_ sender: Any) {
        
        //Reset the button to disable initially.
                playagainBtn.isHidden = true
                //clear the label
                lettersGuessed = ""
                count += 1
                //if count reaches the end of the array (all the words are guessed sucessfully), then print Congratualtions in the status label.
                if count == words.count{
                    
                    statusLabel.text = "Congruations! You are done with the game!"
                    //clearing the labels.
                    DisplayLabel.text = ""
                    HintLabel.text = ""
                }
                else{
                    //fetch the next word from the array
                    word = words[count][0]
                    //fetch the hint related to the word
                    HintLabel.text = "Hint: "
                    HintLabel.text! += words[count][1]
                    //Enabling the check button.
                    checkBtn.isEnabled = true
                    
                    DisplayLabel.text = ""
                    updateUnderscores()
                }
    }
    
    
    @IBAction func enterlabelChanged(_ sender: UITextField) {
        
        //Read the data from the text field
                var textEnterd = letterEntered.text!;
                //Consider only the last character by calling textEntered.last and trimming the white spaces.
                textEnterd = String(textEnterd.last ?? " ").trimmingCharacters(in: .whitespaces)
                letterEntered.text = textEnterd
                
                //Check whether the entered text is empty or not to enable check button.
                if textEnterd.isEmpty{
                    checkBtn.isEnabled = false
                }
                else{
                    checkBtn.isEnabled = true
                }
    }
    
    func updateUnderscores(){
        for letter in word{
            DisplayLabel.text! += "_ "
        }
    }
    
}


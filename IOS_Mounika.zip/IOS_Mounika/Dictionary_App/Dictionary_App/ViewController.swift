//
//  ViewController.swift
//  Dictionary_App
//
//  Created by Mounika Jakkula on 11/28/23.
//

import UIKit


class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return words.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableviewoutlet.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        //populate the cell
        cell.textLabel?.text = words[indexPath.row][0]
        //return the cell
        return cell
    }
    
    
    var words  = [["Benevolent🤗","well-meaning and kindly"],["Courage😒","ability to do something"],["Genuine🧐","true is said to be"],["Hope🫢","A feeling of exception"],["joy","A feeling of great"]]
    
    
    
    

    @IBOutlet weak var tableviewoutlet: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableviewoutlet.delegate = self
        tableviewoutlet.dataSource = self
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(transition == "result"){
            let destination = segue.destination as!
            DeatilViewController
            destination.name = words[(tableviewoutlet.indexPathForSelectedRow?.row)!][0]
            destination.meaning1 = words[(tableviewoutlet.indexPathForSelectedRow?.row)!][1]


        }
    }

}

//
//  DeatilViewController.swift
//  Dictionary_App
//
//  Created by Mounika Jakkula on 11/28/23.
//

import UIKit

class DeatilViewController: UIViewController {

    var name = ""
    var meaning1 = ""
    
    @IBOutlet weak var word: UILabel!
    
    
    @IBOutlet weak var meaning: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        word.text = "\(name)"
        meaning.text = "\(meaning1)"
        print(meaning1)
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

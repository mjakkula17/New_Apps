//
//  ViewController.swift
//  Laptops
//
//  Created by Mounika Jakkula on 10/3/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var imageDisplay: UIImageView!
    
    @IBOutlet weak var laptopname: UILabel!
    
    @IBOutlet weak var OriginalPrice: UILabel!
    
    //@IBOutlet weak var taxinputOL: UILabel!
    
    @IBOutlet weak var taxinputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    @IBOutlet weak var prevBtn: UIButton!
    
    @IBOutlet weak var NextBtn: UIButton!
    
        
    //creating an array for list of laptops
    var laptops = [["img01","HP","1000"],["img02","Mac","1500"],["img03","Lenovo","1300"]]
    var imageNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        prevBtn.isEnabled = false
        UpdateDisplay(imageNumber)
        imageDisplay.image = UIImage(named: laptops[0][0])
        
    }

    @IBAction func submitBtn(_ sender: Any) {
        
        var amount:Double = 0.0
        amount = Double(OriginalPrice.text!)!
        
        var taxpercent:Double = 0.0
        taxpercent = Double(taxinputOL.text!)!
        
        var tax = amount * taxpercent
        var finalprice = tax + amount
        
        //outputOL.text:Double = 0.0
        outputOL.text! = String(Double(finalprice))
        
        
    }
    
    
    @IBAction func prevBtnClicked(_ sender: UIButton) {
        
        //next button should be enabled
        NextBtn.isEnabled = true
        
        //decrement the imagenumber
        imageNumber -= 1
        
        //update the display function
        UpdateDisplay(imageNumber)
        if(imageNumber == 0)
        {
            prevBtn.isEnabled = false
        }
        //
        
        //call the updateDisplay() method
        //updateDisplay(imageNumber)
        
        //Disable previous button for first element in arrray
        //if(imageNumber == 0) {
            //previousBtnOL.isEnabled = false
        
        
    }
    
    @IBAction func nextBtnClicked(_ sender: UIButton) {
        prevBtn.isEnabled = true
        
        imageNumber += 1
        UpdateDisplay(imageNumber)
        
        if(imageNumber == laptops.count-1){
            NextBtn.isEnabled = false
        }
        
    }
    
    func UpdateDisplay(_ imageNumber:Int){
        laptopname.text = laptops[imageNumber][1]
        OriginalPrice.text = laptops[imageNumber][2]
        imageDisplay.image = UIImage(named: laptops[imageNumber][0])
    }
}


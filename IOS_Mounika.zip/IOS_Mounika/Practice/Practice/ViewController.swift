//
//  ViewController.swift
//  Practice
//
//  Created by Mounika Jakkula on 11/13/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameOL: UITextField!
    
    @IBOutlet weak var idOL: UITextField!
    
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var statusOL: UILabel!
    
    @IBOutlet weak var phyBtn: UIButton!
    
    @IBOutlet weak var resvBtn: UIButton!
    
    //var patients: [Patient] = [] // Assume you have loaded patient data
    var patientFound = PatientDetails()
    
    var isPatient = false
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        statusOL.isHidden = true
        phyBtn.isHidden = true
        resvBtn.isHidden = true
    }
    
    
    @IBAction func checkpatientid(_ sender: UITextField) {
        
        //value of the textField
        let enteredID = idOL.text!
        var input = idOL.text!
        for patient in patientsArray {
            if enteredID == patient.patientId{
                
                nameOL.text! = "Aish"
                idOL.text! = String(PatientDetails(patientId: "asd"))
                statusOL.text! = "Patient \(input) is found"
                
                
                //var input = idOL.text!
                //Loop the array to find the student
                //for patient in patientsArray {
                //if enteredID == patient.patientId{
                //student found and store the student in a global variable.
                //patientFound = patient
                //boolean flag as true,since we found a student.
                //isPatient = true
                //statusOL.text! = "Patient \(input) is found"
                
                
                
            }
        }
    }
    
    @IBAction func physicianBtnClicked(_ sender: UIButton) {
        
        
    }
    
    
    @IBAction func reservBtnClicked(_ sender: UIButton) {
    }
    
    
    
    
    
}

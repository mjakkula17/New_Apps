//
//  ViewController.swift
//  Jakkula_SearchApp
//
//  Created by Mounika Jakkula on 10/30/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var prevBtnclicked: UIButton!
    
    @IBOutlet weak var nextBtnClicked: UIButton!
    
    @IBOutlet weak var resetBtn: UIButton!
    
    @IBOutlet weak var searchBtn: UIButton!
    
    var presntimgindex = 0
    var imagesoftopics: [String] = []
    var descriptionsoftopics: [String] = []
    var presntkeyword: [String] = []
    
    //Array images of flowers
    var flowrImages: [String] = ["Jasmine","lilly","Rose", "Mariegold", "lotus"]
    
    
    //Array description of flowers
    var flowrsDescriptions: [String] = [
            "Jasmine is a genus of plants. asmine is a climbing vine in the olive family found throughout tropical areas of Europe, Asia and Africa.",
            "Lillies are among the oldest cultivated plants. In Chinese culture, lilies are known to symbolize good luck and long lasting love. In addition to their usage at religious ceremonies, lilies have also been used for medicinal purposes. The buds or oils of the lily have been known to reduce fever and make skin more firm, thus lessening wrinkles.",
            "A rose is a type of shrub. The Greek legends narrate how the white rose first sprang during the birth of Aphrodite, the Goddess of Purity. The association of rose with love is also a concept passed on from myths that relate how the name of Eros, the God of Love, can be rearranged to form the word 'rose'",
            "Mariegold flowers are usually red, orange, or yellow. Marigold shows anti-bacterial and anti-viral properties, which make them special. They grow once a year. They are 1 to 5 feet in height. They need 5-6 hours of sunlight every day to grow properly.",
            "The lotus flower is regarded as the National Flower of India. The lotus flower meaning varies from culture to culture. In general, however, the lotus commonly serves as a sacred for purity, rebirth."
        ]
    
    //Arrays for keywords of flowers
    var flowr_keywords: [String] = ["plants", "flowers", "shrub"]
    
    
    
    //Array images of food
    var foodImages: [String] = ["Dosa","Idly","Chapathi", "Puri", "Upma"]
    
    //Array description of food
    var foodDescriptions: [String] = [
            "A dosa is a thin savory crepe in South Indian cuisine. Paper Dosa, also known as Sada Dosa or Plain Dosa, is a popular South Indian dish that is enjoyed as a breakfast or snack. It is a thin, crispy crepe made from a batter of fermented rice and urad dal (black gram). Paper Dosa is usually served with sambar and coconut chutney or tomato chutney.",
            "Idly is a type of savoury rice cake, originating from South India, popular as a breakfast food in Southern India and in Sri Lanka. The cakes are made by steaming a batter consisting of fermented black lentils (de-husked) and rice.",
            "Chapathis are one of the most common forms of wheat bread. A round flat unleavened bread of India that is usually made of whole wheat flour and cooked on a griddle.",
            "Puri is a deep-fried bread made from unleavened whole-wheat flour that originated in the Indian subcontinent. It is eaten for breakfast or as a snack or light meal. It is usually served with a savory curry or bhaji, as in puri bhaji, but may also be eaten with sweet dishes.",
            "Upma is a flavorful, tasty, savory and popular South Indian breakfast. It is a dish originating from the Indian subcontinent, most common in Kerala, Andhra Pradesh, Tamil Nadu, Telangana, Karnataka, Maharashtrian, and Sri Lankan Tamil breakfast, cooked as a thick porridge from dry-roasted semolina or coarse rice flour."
        ]
    
    //Arrays for keywords of food
    var food_keywords: [String] = ["cuisine", "wheat", "breakfast","food"]
    
    
    //Array images of Heros
    var HeroImages: [String] = ["Prabhas","NTR","Ramcharan", "Rana", "Nani"]
    
    //Array description of Heros
    var HeroDescriptions: [String] = [
            "Prabhas was born into a Telugu-speaking family to film producer Uppalapati Surya Narayana Raju. Prabhas is the first South Indian actor to receive a wax sculpture at Madame Tussaud's wax museum. In addition to his film career, he is widely known for promoting various humanitarian and philanthropic causes. He is the brand ambassador for the Mahindra TUV300.",
            "NTR is one of the most popular Indian actors. He is an Indian film actor, Kuchipudi dancer, playback singer and television personality known for his works in Telugu cinema. He is the grandson of Telugu actor, and former chief minister of Andhra Pradesh.",
            "Ram Charan is one of the highest-paid actors in Indian cinema. Ram is an Indian actor, producer, and entrepreneur who works predominantly in Telugu cinema. One of the highest-paid Telugu film actors, he is the recipient of three Filmfare Awards and two Nandi Awards. Since 2013, he has featured in Forbes India's Celebrity 100 list.",
            "Rana is known as the vicious antagonist Bhallaladeva. Rana Suresh Babu Daggubati is an Indian film actor, producer, visual effects co-ordinator, and photographer known for his works in Telugu, Tamil and Hindi cinema. He was born in Chennai, Tamil Nadu, to Telugu film producer Daggubati Suresh Babu.",
            "Nani is an Indian actor, producer, and television presenter. Ghanta Naveen Babu (born 24 February 1984), known professionally by his screen name Nani, is an Indian actor, producer, and television presenter known primarily for his work in Telugu cinema. Acclaimed for his versatile acting, he has received two Filmfare Awards and two Nandi Awards for his work."
        ]
    
    //Arrays for keywords of Heros
    var Hero_keywords: [String] = ["film", "popular", "actors"]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        searchBtn.isEnabled = false
        resultImage.image =  UIImage(named: "welcome")

        
    }
    
    
    @IBAction func searchTextField(_ sender: Any) {
        searchBtn.isEnabled = true
        
        nextBtnClicked.isHidden = false
        prevBtnclicked.isHidden = false
        resetBtn.isHidden = false
    }
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        guard let searchText = searchTextField.text?.lowercased() else {
                    return
                }
                
                // It is to determine the topic based on the entered keyword
                var selctdtopic: (images: [String], descriptions: [String], keywords: [String])? = nil
                
                if flowr_keywords.contains(searchText) {
                    selctdtopic = (flowrImages, flowrsDescriptions, flowr_keywords)
                }
                else if food_keywords.contains(searchText) {
                    selctdtopic = (foodImages, foodDescriptions, food_keywords)
                }
                else if Hero_keywords.contains(searchText) {
                    selctdtopic = (HeroImages, HeroDescriptions, Hero_keywords)
                }
                
                
                if let topic = selctdtopic {
                    imagesoftopics = topic.images
                    descriptionsoftopics = topic.descriptions
                    
                    // It is to disable the previous button at the starting of the search
                    prevBtnclicked.isEnabled = false
                    
                    // It is to display the first image and description
                    if !imagesoftopics.isEmpty {
                        presntimgindex = 0
                        resultImage.image = UIImage(named: imagesoftopics[presntimgindex])
                        topicInfoText.text = descriptionsoftopics[presntimgindex]
                    }
                } else {
                    //It is for to display search not found if we search anything that is not matched with any keywords
                    resultImage.image = UIImage(named: "searchnotfound")
                    topicInfoText.text = "Your search is not found"
                    nextBtnClicked.isHidden = true
                    prevBtnclicked.isHidden = true
                    resetBtn.isHidden = true
                   
                }
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        if presntimgindex < imagesoftopics.count - 1 {
            presntimgindex += 1
            resultImage.image = UIImage(named: imagesoftopics[presntimgindex])
            topicInfoText.text = descriptionsoftopics[presntimgindex]
        }
        // Update button status
            UpdateBtnstatus()
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        if presntimgindex > 0 {
            presntimgindex -= 1
            resultImage.image = UIImage(named: imagesoftopics[presntimgindex])
            topicInfoText.text = descriptionsoftopics[presntimgindex]
                }
        // Update button status
            UpdateBtnstatus()
        
    }
    
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        
        nextBtnClicked.isHidden = true
        prevBtnclicked.isHidden = true
        resetBtn.isHidden = true
        
        searchBtn.isEnabled = false
        searchTextField.text = ""
        topicInfoText.text = "It is resetted"
        // Set the image back to "welcome" image
        resultImage.image = UIImage(named: "welcome")
        presntimgindex = 0
        
        prevBtnclicked.isEnabled = true
        nextBtnClicked.isEnabled = true
    }
    
    func UpdateBtnstatus() {
        // It is to disable the previous button at the start of the image array
        // and the next button at the end of the image array
        if presntimgindex == 0 {
            // at the beginning disable the previous button
            prevBtnclicked.isEnabled = false
        } else {
            // From the next of starting enable previous button
            prevBtnclicked.isEnabled = true
        }
        
        if presntimgindex == imagesoftopics.count - 1 {
            // At the end disable next button
            nextBtnClicked.isEnabled = false
        } else {
            // Before end enable the next button
            nextBtnClicked.isEnabled = true
        }
    }
    
}


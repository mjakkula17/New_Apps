//
//  ViewController.swift
//  Jakkula_Exam01
//
//  Created by Mounika Jakkula on 10/5/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imageDisplay: UIImageView!
    
    @IBOutlet weak var NameinputOL: UITextField!
    
    
    @IBOutlet weak var RoomTypeinputOL: UITextField!
    
    
    @IBOutlet weak var MembershipinputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calcpriceBtn(_ sender: Any) {
        
        
        var name:String = " "
        name = String(NameinputOL.text!)
        var roomType:String = " "
        roomType = String(RoomTypeinputOL.text!)
        var membership:String = " "
        membership = String(MembershipinputOL.text!)
        //calculating for single bed
        if(roomType == "Single-Bed") || (roomType == "single-bed"){
            
            if(membership == "Yes") || (membership == "yes")
            {
                imageDisplay.image = UIImage(named: "Single_Img.jpeg")
                
                
                var roomTypePrice:Double = 0.0
                roomTypePrice = 74.99
                
                var discountRate:Double = 0.0
                discountRate = 5
                var taxPercentage:Double = 0.0
                taxPercentage = 16.75
                
                var Discountedprice = (roomTypePrice * (discountRate/100))
                var totalpricewithtax = roomTypePrice + (roomTypePrice * (taxPercentage/100))
                outputOL.text! = String(format: "%.2f",Double(totalpricewithtax - Discountedprice))
                
                
                
            }
            else if(membership == "No") || (membership == "no") {
                imageDisplay.image = UIImage(named: "Single_Img.jpeg")
                
                var roomTypePrice:Double = 0.0
                roomTypePrice = 74.99
                
                var discountRate:Double = 0.0
                discountRate = 5
                var taxPercentage:Double = 0.0
                taxPercentage = 16.75
                
                var Discountedprice = roomTypePrice - (roomTypePrice * (discountRate/100))
                var totalpricewithtax = roomTypePrice + (roomTypePrice * (taxPercentage/100))
                outputOL.text! = String(format: "%.2f",Double(totalpricewithtax))
                
            }
                
        }
        //calculating for double bed
        else if(roomType == "Double-Bed") || (roomType == "double-bed"){
            
            if(membership == "Yes") || (membership == "yes")
            {
                imageDisplay.image = UIImage(named: "Double_Img.jpeg")
                
                
                var roomTypePrice:Double = 0.0
                roomTypePrice = 84.99
                
                var discountRate:Double = 0.0
                discountRate = 5
                var taxPercentage:Double = 0.0
                taxPercentage = 16.75
                
                var Discountedprice = (roomTypePrice * (discountRate/100))
                var totalpricewithtax = roomTypePrice + (roomTypePrice * (taxPercentage/100))
                outputOL.text! = String(format: "%.2f",Double(totalpricewithtax - Discountedprice))
                
                
                
            }
            else if(membership == "No") || (membership == "no") {
                imageDisplay.image = UIImage(named: "Double_Img.jpeg")
                
                var roomTypePrice:Double = 0.0
                roomTypePrice = 84.99
                
                var discountRate:Double = 0.0
                discountRate = 5
                var taxPercentage:Double = 0.0
                taxPercentage = 16.75
                
                var Discountedprice = roomTypePrice - (roomTypePrice * (discountRate/100))
                var totalpricewithtax = roomTypePrice + (roomTypePrice * (taxPercentage/100))
                outputOL.text! = String(format: "%.2f",Double(totalpricewithtax))
                
            }
                
        }
        else
        {
            imageDisplay.image = UIImage(named: "NoRoom_Img.jpeg")
            
        }
       
        
    }
    
    
    @IBAction func resetBtn(_ sender: Any) {
        //resets all the values
    }
    
}


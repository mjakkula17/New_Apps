//
//  genreCollectionViewCell.swift
//  Filmfusion
//
//  Created by Tejaswi Maddela on 11/18/23.
//

import UIKit

class genreCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var genreImageOL: UIImageView!
}

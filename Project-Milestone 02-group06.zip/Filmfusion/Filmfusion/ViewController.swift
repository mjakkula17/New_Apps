//
//  ViewController.swift
//  Filmfusion
//
//  Created by Tejaswi Maddela on 11/18/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func logoButton(_ sender: Any) {
    }
    
}


//
//  recommendationCollectionViewCell.swift
//  Filmfusion
//
//  Created by Tejaswi Maddela on 11/18/23.
//

import UIKit

class recommendationCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var recommendationImageOL: UIView!
}

//
//  movieCollectionViewCell.swift
//  Filmfusion
//
//  Created by Tejaswi Maddela on 11/18/23.
//

import UIKit

class movieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var movieImageOL: UIView!
}

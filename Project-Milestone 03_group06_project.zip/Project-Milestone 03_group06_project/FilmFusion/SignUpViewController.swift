//
//  SignUpViewController.swift
//  FilmFusion
//
//  Created by Mounika Jakkula on 12/5/23.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var NameOL: UITextField!
    
    @IBOutlet weak var EmailOL: UITextField!
    
    @IBOutlet weak var PasswordOL: UITextField!
    
    @IBOutlet weak var RePasswordOL: UITextField!
    
    
    @IBOutlet weak var SignUpOL: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        SignUpOL.isHidden = false
    }
    
    @IBAction func SignUpBTN(_ sender: UIButton) {
        var a = EmailOL.text!
        var acc = Account(email: a, password: RePasswordOL.text!,flag : true)
        Acnt.append(acc)
        
        NameOL.text = ""
        EmailOL.text = ""
        PasswordOL.text = ""
        RePasswordOL.text = ""
        act = acc
        
    }
    
    @IBAction func CheckPasswordBTN(_ sender: UITextField) {
        
        let pass1 = PasswordOL.text!
        let pass2 = RePasswordOL.text!
        if(pass1==pass2){
            SignUpOL.isHidden = false
           
        }
        else{
            SignUpOL.isHidden = true
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  MovieData.swift
//  FilmFusion
//
//  Created by SwarupaJinne on 12/4/23.
//

import Foundation
import UIKit

struct Movie {
    var title : String?
    var image : UIImage?
    var releasedYear : String?
    var movieRating : String?
    var boxOffice : String?
    var moviePlot : String?
    var cast : [String] = []
    var trailer : String?

    
}


struct Genre {
    var category : String
    var movies : [Movie] = []
}



let arrayGenre1 = Genre(category: "Action",movies: [Movie(title: "Action", image: UIImage(named: "Action"), releasedYear: "2003", movieRating: "8.1", boxOffice: "654M", moviePlot: "Capt. Jack Sparrow (Johnny Depp) arrives at Port Royal in the Caribbean without a ship or crew.", cast: ["Vishal", " Raashi Khanna ", " Venkat Mohan"], trailer: "N7xmiGw9oVc"),
 Movie(title: "Chanakya", image: UIImage(named: "Chanakya"), releasedYear: "2018", movieRating: "7.8", boxOffice: "520M", moviePlot: "An undercover agent (Actor) is tasked with thwarting a terrorist plot that could have devastating consequences for the nation. The agent must navigate a web of deceit and danger.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "0mUcB56OOZI"),
    Movie(title: "Nayak", image: UIImage(named:"Nayak") ,releasedYear: "2005", movieRating: "8.5", boxOffice: "700M", moviePlot: "A common man (Actor) is unexpectedly thrust into the political limelight and must navigate the treacherous world of politics while confronting corruption and injustice.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "W03c_X8VcV0"),
    Movie(title: "custody", image: UIImage(named: "custody"), releasedYear: "2010", movieRating: "7.5", boxOffice: "450M", moviePlot: "A dedicated police officer (Actor) must protect a key witness (Actress) in a high-profile case, facing numerous challenges and threats along the way.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "KavrRIh0ScQ"),
     Movie(title: "Dhruva", image: UIImage(named: "Dhruva"), releasedYear: "2015", movieRating: "8.0", boxOffice: "600M", moviePlot: "In a futuristic city, a brilliant detective (Actor) investigates a series of high-tech crimes, uncovering a conspiracy that shakes the foundations of society.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: " vINrat94sFc")])



let arrayGenre2 = Genre(category: "Comedy",movies: [Movie(title: "Kaleja", image: UIImage(named: "Kaleja"),releasedYear: "2011", movieRating: "7.9", boxOffice: "580M", moviePlot: "A mysterious man (Actor) with extraordinary abilities becomes the key to uncovering a hidden ancient power. As dark forces try to seize this power, the man must embrace his destiny and save the world.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "RaChQXib_f8"),
    Movie(title: "Kiladi", image: UIImage(named: "Kiladi"), releasedYear: "2013", movieRating: "8.2", boxOffice: "620M", moviePlot: "A charismatic daredevil (Actor) finds himself entangled in a web of conspiracies and deceit when he stumbles upon a high-stakes game. With danger at every turn, he must use his wit and skills to outsmart his enemies.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "UFI7WViURME"),
  Movie(title: "Julai", image: UIImage(named: "Julai"), releasedYear: "2012", movieRating: "8.0", boxOffice: "600M", moviePlot: "A witty and resourceful undercover agent (Actor) is tasked with bringing down a notorious criminal syndicate. As he navigates through a world of intrigue and danger, he discovers shocking secrets that change the course of the mission.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "YzmjCwPiLbk"),
 Movie(title: "Racegurram", image: UIImage(named: "Racegurram"), releasedYear: "2014", movieRating: "8.4", boxOffice: "700M", moviePlot: "Two brothers (Actor, Supporting Actor) with contrasting personalities find themselves embroiled in a high-stakes race against time and ruthless criminals. With adrenaline-pumping action and unexpected twists, they must overcome all odds.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "oVsA6B1cweo"),
    Movie(title: "Kick", image: UIImage(named:"Kick"), releasedYear: "2014", movieRating: "8.7", boxOffice: "750M", moviePlot: "A charismatic and unpredictable vigilante (Actor) seeks thrill and justice in equal measure. His unconventional methods and high-stakes escapades make him a formidable force against crime, as he outsmarts both law enforcement and criminals.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "Rb8GCqEv1qQ")])



let arrayGenre3 = Genre(category: "Horror",movies: [Movie(title: "Arundhati", image: UIImage(named: "Arundhati"), releasedYear: "2007", movieRating: "8.5", boxOffice: "700M", moviePlot: "A brave princess (Actress) discovers her destiny intertwined with a dark and ancient curse. To save her kingdom, she must confront supernatural forces and unravel the mysteries of her past.", cast: ["Actress", "Supporting Actor", "Supporting Actress"], trailer: "0bEZ1NhcCOc"),
    Movie(title: "Lissa", image: UIImage(named: "Lissa"), releasedYear: "2014", movieRating: "7.8", boxOffice: "550M", moviePlot: "A renowned paranormal investigator (Actor) is called to uncover the chilling secrets behind a haunted mansion. As he delves into the supernatural, he must face his own fears and the malevolent spirits within.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "mwJwoLBSK50"),
  Movie(title: "Kaalika", image: UIImage(named: "Kaalika"), releasedYear: "2019", movieRating: "7.2", boxOffice: "480M", moviePlot: "In a small town plagued by a series of gruesome murders, a determined detective (Actor) must unravel the dark secrets surrounding an ancient cult. As the body count rises, the detective is drawn into a web of horror and suspense.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "RJlAfZblftY"),
 Movie(title: "Paapa", image: UIImage(named: "Paapa"), releasedYear: "2015", movieRating: "8.0", boxOffice: "600M", moviePlot: "A grieving mother (Actress) seeks justice for her daughter's mysterious death, uncovering a sinister conspiracy. As she battles against corrupt officials and dangerous criminals, the mother becomes an avenging force.", cast: ["Actress", "Supporting Actor", "Supporting Actress"], trailer: "74DbvHMvmGg"),
Movie(title: "ColdCase", image: UIImage(named: "ColdCase"), releasedYear: "2021", movieRating: "8.8", boxOffice: "750M", moviePlot: "A brilliant detective (Actor) reopens a long-forgotten murder case that holds the key to solving a recent string of mysterious deaths. As he digs deeper, he unravels a complex web of deceit and supernatural phenomena.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "rbzvgKw1SEI"),
Movie(title: "KasturiMahal", image: UIImage(named: "KasturiMahal"), releasedYear: "2018", movieRating: "7.5", boxOffice: "520M", moviePlot: "An archaeologist (Actor) discovers an ancient palace with a dark history. As he explores the secrets within, supernatural forces are unleashed, and the archaeologist must confront the malevolent spirits haunting the Kasturi Mahal.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "vAXrKz0cz4w"),
Movie(title: "RajuGariGadhi", image: UIImage(named: "RajuGariGadhi"), releasedYear: "2015", movieRating: "7.9", boxOffice: "590M", moviePlot: "A group of friends (Actor, Actress, Supporting Actor) opens a haunted hotel, only to discover that the spirits within are more real than they thought. As the friends face paranormal encounters, they must unravel the mysteries of the hotel's dark past.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "jVTteS_AZ-0"),
    Movie(title: "Kaanchana", image: UIImage(named:"Kaanchana") , releasedYear: "2011", movieRating: "8.3", boxOffice: "680M", moviePlot: "A man (Actor) is possessed by the vengeful spirit of a transgender woman, seeking justice for her unjust death. Filled with horror and dark humor, the man must navigate the challenges of being haunted and the supernatural battles that follow.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "LSUO6qyNWhE")])


let arrayGenre4 = Genre(category: "Thriller",movies: [Movie(title: "VasanthaKalam", image: UIImage(named: "VasanthaKalam"), releasedYear: "2020", movieRating: "8.4", boxOffice: "670M", moviePlot: "In the idyllic town of Vasantha Kalam, a group of friends (Actor, Actress, Supporting Actor) stumbles upon a dark secret from the past. As they dig deeper, they find themselves entangled in a web of love, betrayal, and mystery.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "fs_ZbMDYVtg"),
    Movie(title: "Forensic", image: UIImage(named: "Forensic"), releasedYear: "2019", movieRating: "8.7", boxOffice: "720M", moviePlot: "A brilliant forensic expert (Actor) is tasked with solving a series of gruesome murders that share a common link. As he delves into the minds of the killers, he unravels a chilling conspiracy that leads him to the heart of darkness.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "pYQ0BwvyUvw"),
  Movie(title: "Detective", image: UIImage(named: "Detective"), releasedYear: "2017", movieRating: "7.9", boxOffice: "590M", moviePlot: "A seasoned detective (Actor) with a sharp mind and a troubled past takes on a high-profile case. As he navigates the murky world of crime and corruption, he must confront his own demons and expose the truth hidden in the shadows.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "f1Hk0jV_t9M"),
 Movie(title: "Mantra", image: UIImage(named: "Mantra"), releasedYear: "2016", movieRating: "7.5", boxOffice: "540M", moviePlot: "A mysterious ancient mantra (Artifact) with supernatural powers becomes the focal point of a gripping tale. Those who seek it are drawn into a battle between good and evil, where the mantra's secrets hold the key to unimaginable power.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "qE8q3aJbrN0"),
Movie(title: "Kanam", image: UIImage(named: "Kanam"), releasedYear: "2018", movieRating: "8.0", boxOffice: "610M", moviePlot: "A young woman (Actress) discovers her extraordinary ability to communicate with the deceased. As she grapples with this gift, she becomes entwined in a family's tragic history, leading to a confrontation between the living and the dead.", cast: ["Actress", "Supporting Actor", "Supporting Actress"], trailer: "huc4AKH2eLI"),
Movie(title: "Drushyam", image: UIImage(named: "Drushyam"), releasedYear: "2015", movieRating: "9.2", boxOffice: "780M", moviePlot: "A simple man (Actor) must use his wit and intelligence to protect his family when they become unwittingly involved in a crime. As the investigation intensifies, he weaves a complex web of deception to shield his loved ones from the harsh truths.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "xMfaAjP8wJE")])



let arrayGenre5 = Genre(category: "Mystery",movies: [Movie(title: "Serial Killer", image: UIImage(named: "SerialKiller"), releasedYear: "2018", movieRating: "7.6", boxOffice: "560M", moviePlot: "A relentless detective (Actor) is on the trail of a cunning serial killer terrorizing the city. As the body count rises, the detective must navigate the twisted mind of the killer to stop their deadly spree.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "lnyl_p4dEsc"),
    Movie(title: "Mystery of Sarika", image: UIImage(named: "MysteryOfSarika"), releasedYear: "2019", movieRating: "7.8", boxOffice: "580M", moviePlot: "A journalist (Actress) investigates the mysterious disappearance of a popular actress, unraveling a web of secrets and conspiracies. As she gets closer to the truth, she becomes the target of those who will stop at nothing to keep the mystery hidden.", cast: ["Actress", "Supporting Actor", "Supporting Actress"], trailer: "NTlOkzuaR-0"),
    Movie(title: "Petromax", image: UIImage(named: "Petromax"), releasedYear: "2020", movieRating: "7.5", boxOffice: "540M", moviePlot: "A group of friends (Actor, Actress, Supporting Actor) decides to spend a night in a haunted mansion, hoping to prove the existence of ghosts. However, when they accidentally awaken an ancient spirit, hilarity and horror ensue.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "E8pb-jsYZdc")])


let arrayGenre6 = Genre(category: "Historical",movies: [Movie(title: "Yuganiki Okkadu", image: UIImage(named: "YuganikiOkkadu"), releasedYear: "2013", movieRating: "8.3", boxOffice: "660M", moviePlot: "An archaeologist (Actor) stumbles upon an ancient artifact that holds the key to a lost civilization. As he embarks on a journey to unlock its mysteries, he must face formidable challenges and rivals seeking the artifact's power.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "FXJ3d_1n9yo"),
    Movie(title: "Kartikeya", image: UIImage(named: "Kartikeya"), releasedYear: "2017", movieRating: "7.9", boxOffice: "590M", moviePlot: "A modern-day warrior (Actor) discovers his true identity as a reincarnation of the legendary deity Kartikeya. With divine powers and a sacred mission, he must confront ancient evils that threaten to plunge the world into chaos.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "DlgEni0fZiU"),
  Movie(title: "Sahasam", image: UIImage(named: "Sahasam"), releasedYear: "2015", movieRating: "8.0", boxOffice: "600M", moviePlot: "A fearless adventurer (Actor) embarks on a quest to find a hidden treasure, facing treacherous landscapes and deadly foes. As he journeys into the heart of danger, he discovers the true value of courage and perseverance.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "Z7JkBGg9LQ0"),
 Movie(title: "Polimera", image: UIImage(named: "Polimera"), releasedYear: "2018", movieRating: "7.5", boxOffice: "520M", moviePlot: "In a dystopian future, a lone hero (Actor) rises against a tyrannical regime that controls the world's resources. With advanced technology and unmatched skills, he becomes the symbol of resistance in the fight for freedom.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "y5bLBn5Zkz4"),
Movie(title: "Jeans", image: UIImage(named: "Jeans"), releasedYear: "2001", movieRating: "8.6", boxOffice: "710M", moviePlot: "A pair of magical jeans (Artifact) brings unexpected twists and turns into the lives of those who possess them. As the jeans change hands, they influence love, friendship, and destiny in ways no one could have imagined.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "GXao7KtgGqw")])

let arrayGenre7 = Genre(category: "Mythological",movies: [Movie(title: "Diksoochi", image: UIImage(named: "Diksoochi"), releasedYear: "2014", movieRating: "7.8", boxOffice: "560M", moviePlot: "A brilliant inventor (Actor) creates a device that allows users to explore their own dreams. However, as people delve into their subconscious, they uncover dark secrets and hidden fears that threaten to consume them.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "lbAV5HWpxsE"),
    Movie(title: "Kurukshetram", image: UIImage(named: "Kurukshetram"), releasedYear: "2019", movieRating: "8.2", boxOffice: "640M", moviePlot: "In the political battlefield of Kurukshetram, a noble warrior (Actor) must navigate the complexities of power, loyalty, and betrayal. As he faces formidable opponents, he discovers the true meaning of honor and sacrifice.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "AXgGB3tjGXM"),
  Movie(title: "Magadhera", image: UIImage(named: "Magadhera"), releasedYear: "2009", movieRating: "9.0", boxOffice: "780M", moviePlot: "In the ancient kingdom of Magadhera, a valiant prince (Actor) must defend his land and love against dark forces. With epic battles and mythical creatures, Magadhera becomes a timeless tale of heroism and destiny.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "G7haVu5g-Qw"),
   Movie(title: "Baahubali", image: UIImage(named: "Baahubali"), releasedYear: "2015", movieRating: "9.5", boxOffice: "900M", moviePlot: "The epic saga of Baahubali unfolds as a prince (Actor) discovers his true lineage and battles for the throne. With breathtaking visuals and a gripping narrative, Baahubali becomes a cinematic spectacle that captivates audiences worldwide.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "CycUs6wlRME"),
    Movie(title: "Pournami", image: UIImage(named: "Pournami"), releasedYear: "2006", movieRating: "8.0", boxOffice: "620M", moviePlot: "A young dancer (Actress) embarks on a mystical journey to fulfill an ancient prophecy. As she faces trials and tribulations, Pournami discovers her true destiny and the power within her to change the course of history.", cast: ["Actress", "Supporting Actor", "Supporting Actress"], trailer: "Sa9xD8ZNtfk"),
    Movie(title: "Panchakshari", image: UIImage(named: "Panchakshari"), releasedYear: "2010", movieRating: "7.5", boxOffice: "540M", moviePlot: "A woman (Actress) discovers she is the chosen one with the power to defeat an ancient evil. With the guidance of mystical forces, she must embrace her destiny and confront the malevolent entities threatening the world.", cast: ["Actress", "Supporting Actor", "Supporting Actress"], trailer: "rNE7MP0QEhc")])

let arrayGenre8 = Genre(category: "Romance",movies: [Movie(title: "Godavari", image: UIImage(named: "Godavari"), releasedYear: "2006", movieRating: "8.2", boxOffice: "640M", moviePlot: "A group of friends (Actor, Actress, Supporting Actor) embarks on a picturesque journey along the Godavari River. As they navigate the river's twists and turns, they discover the beauty of friendship and the importance of cherishing moments.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "k_-PvLgr1c0"),
    Movie(title: "Mad", image: UIImage(named: "Mad"), releasedYear: "2018", movieRating: "7.7", boxOffice: "570M", moviePlot: "In a world where emotions are suppressed, a rebellious young man (Actor) discovers the power of love and passion. As he challenges the rigid societal norms, he becomes the catalyst for change in a dystopian society.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "rnUgO_klwnE"),
  Movie(title: "Chalo", image: UIImage(named: "Chalo"), releasedYear: "2018", movieRating: "7.8", boxOffice: "590M", moviePlot: "In a quirky town divided by a geographical boundary, a young man (Actor) discovers that love knows no borders. As he navigates the humorous challenges of the divided town, Chalo becomes a delightful romantic comedy.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "N6GzU2orinc"),
 Movie(title: "Lovers Day", image: UIImage(named: "LoversDay"), releasedYear: "2019", movieRating: "7.6", boxOffice: "560M", moviePlot: "A group of high school friends (Actor, Actress, Supporting Actor) experiences the joys and challenges of first love. As they navigate the complexities of relationships, Lovers Day becomes a heartwarming tale of friendship and romance.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "HUvDnYXM2mQ"),
Movie(title: "Edharu Ammailatho", image: UIImage(named: "EdharuAmmailatho"), releasedYear: "2013", movieRating: "7.5", boxOffice: "540M", moviePlot: "In a tale of mistaken identities, a man (Actor) finds himself entangled with two women. As hilarious and chaotic situations unfold, Edharu Ammailatho becomes a comedy of errors that explores the unpredictability of love.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "Rv3DLPFbQgA"),
Movie(title: "Orange", image: UIImage(named: "Orange"), releasedYear: "2010", movieRating: "8.4", boxOffice: "670M", moviePlot: "A young man (Actor) with a zest for life and a belief in destiny embarks on a journey to find true love. With vibrant visuals and soulful music, Orange becomes a celebration of love, life, and second chances.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "rY9WO1R8Ud8"),
Movie(title: "100% Love", image: UIImage(named: "100PercentLove"), releasedYear: "2011", movieRating: "8.0", boxOffice: "610M", moviePlot: "In a battle of egos and wits, a brilliant student (Actor) competes with his equally intelligent classmate. As they navigate the challenges of academia and love, 100% Love becomes a romantic comedy that explores the complexities of relationships.", cast: ["Actor", "Actress", "Supporting Actor"], trailer: "D06awr4iZMw"),
    Movie(title: "Aarya", releasedYear: "2004", movieRating: "8.2", boxOffice: "600M", moviePlot: "In the compelling tale of Aarya, a charismatic hero (Hero) finds himself entangled in a complex web of love, betrayal, and intrigue. As he navigates the treacherous paths of life, he must confront powerful adversaries and make sacrifices for the ones he holds dear.", cast: ["Hero", "Heroine", "Any Other Actor"], trailer: "WSn-b-G4lrY")])





let arrayGenre9 = Genre(category: "Adventure",movies: [Movie(title: "Pirates of the Carribain", image: UIImage(named: "PiratesoftheCarrabain"), releasedYear: "2003",movieRating: "8.1",boxOffice: "654M",moviePlot: "Capt. Jack Sparrow (Johnny Depp) arrives at Port Royal in the Caribbean without a ship or crew.",cast: ["Johnny Depp", "Keira Knightley", "Orlando Bloom"],trailer:"OAsQnocO4wM"),Movie(title: "Thor", image: UIImage(named:"Thor") , releasedYear: "2011", movieRating: "7", boxOffice: "449M", moviePlot: "As the son of Odin (Anthony Hopkins), king of the Norse gods, Thor (Chris Hemsworth) will soon inherit the throne of Asgard from his aging father. ",cast: ["Chris Hemsworth", "Natalie Portman", "Tom Hiddleston"],trailer: "JOddp-nlNvQ")])
                                                       



let arraygenre = [arrayGenre1,arrayGenre2,arrayGenre3,arrayGenre4,arrayGenre5,arrayGenre6,arrayGenre7,arrayGenre8,arrayGenre9]







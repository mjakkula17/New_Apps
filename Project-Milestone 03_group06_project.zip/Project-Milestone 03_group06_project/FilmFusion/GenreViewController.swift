//
//  GenreViewController.swift
//  FilmFusion
//
//  Created by SwarupaJinne on 12/4/23.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var genredata = arraygenre
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return genredata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = genredata[indexPath.row].category
        return cell
    }
    
    
    
    @IBOutlet weak var genreTableView: UITableView!
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        genreTableView.delegate = self
        genreTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //print("19")
        let transition = segue.identifier
        if(transition=="movieSegue") {
            let destination = segue.destination as! MoviesViewController
            destination.name = genredata[(genreTableView.indexPathForSelectedRow?.row)!]
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

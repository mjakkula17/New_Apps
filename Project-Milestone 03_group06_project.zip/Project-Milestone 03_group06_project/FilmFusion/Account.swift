//
//  Account.swift
//  FilmFusion
//
//  Created by Mounika Jakkula on 12/5/23.
//

import Foundation

struct Account{
    var email: String
    var password: String
    var flag = true

}

var a1 = Account(email: "abcd@gmail.com", password: "123456", flag: true)

var a2 = Account(email: "mounika@gmail.com", password: "moni123", flag: true)

var a3 = Account(email: "test123@gmail.com", password: "test123", flag: true)

var Acnt = [a1,a2,a3]

var act: Account?

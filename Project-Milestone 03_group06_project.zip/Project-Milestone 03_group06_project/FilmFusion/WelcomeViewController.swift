//
//  WelcomeViewController.swift
//  FilmFusion
//
//  Created by SwarupaJinne on 12/4/23.
//

import UIKit

class WelcomeViewController: UIViewController {
    
    
    @IBOutlet weak var WelcomeLabel: UILabel!
    
    
    
    @IBOutlet weak var EmailOL: UITextField!
    
    
    @IBOutlet weak var PasswordOL: UITextField!
    
    
    
    @IBOutlet weak var LoginOL: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        LoginOL.isEnabled = true
    }
    
    
    @IBAction func EmailBTN(_ sender: Any) {
    }
    
    
    @IBAction func PasswordBTN(_ sender: UITextField) {
        let enteredID = EmailOL.text!
        let pw = PasswordOL.text!
        for a in Acnt {
            if enteredID == a.email && pw == a.password{
                LoginOL.isEnabled = true
            }
        }
    }
    
    @IBAction func LoginBTN(_ sender: UIButton) {
        let enteredID = EmailOL.text!
        let pw = PasswordOL.text!
        for a in Acnt {
            if enteredID == a.email && pw == a.password{
                LoginOL.isEnabled = true
                act?.email = enteredID
                act?.password = pw
                act?.flag = true
                print("ssss")
            }
        }
        EmailOL.text = ""
        PasswordOL.text = ""
        
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

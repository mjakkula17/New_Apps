//
//  ViewController.swift
//  VotingEligibility
//
//  Created by Kagitha,Hemanth Sai on 9/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitBtnClicked(_ sender: Any) {
        var age = Double(inputOL.text!)
        
        if(age! >= 18) {
            outputOL.text = "You are eligible to Vote!🙂"
        }
        else {
            outputOL.text = "You are not eligible to vote!!😡😡"
        }
    }
    
}



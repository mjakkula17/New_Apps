//
//  ViewController.swift
//  Jakkula_Exam03
//
//  Created by Mounika Jakkula on 11/30/23.
//

import UIKit



class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return words.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = JakkulaTVOL.dequeueReusableCell(withIdentifier: "JakkulaCell", for: indexPath)
        
        cell.textLabel?.text = words[indexPath.row][0]
        
        return cell
    }
    
    
    var words  = [["Mounika Jakkula🤗","660-528-1108","J. M."],["Jame Smith🤩","660-528-0909","S. J."],["Alex Joy🧐","660-770-6600","J. A."],["Hansh Singh🫢","660-528-1199","S. H."],["John Raj","660-550-0000","R. J."],["Micheal John","660-550-0000","J. M."],["Bob Johnson🤗","660-550-0000","J. B."],["Alex Brown🤗","660-550-0000","B. A."],["Andrea Smith🫢","660-550-0000","S. A."],["Cath Roy🤩","660-550-0000","R. C."]]
    
    

    @IBOutlet weak var JakkulaTVOL: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        JakkulaTVOL.delegate = self
                JakkulaTVOL.dataSource = self
            }
            override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                let transition = segue.identifier
                if(transition == "JakkulaContactSegue"){
                    let destination = segue.destination as!
                    JakkulaContactViewController
                    destination.intials = words[(JakkulaTVOL.indexPathForSelectedRow?.row)!][2]
                    destination.phonenumber = words[(JakkulaTVOL.indexPathForSelectedRow?.row)!][1]


                }
            }
        }


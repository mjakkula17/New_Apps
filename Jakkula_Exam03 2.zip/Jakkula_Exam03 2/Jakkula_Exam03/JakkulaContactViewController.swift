//
//  JakkulaContactViewController.swift
//  Jakkula_Exam03
//
//  Created by Mounika Jakkula on 11/30/23.
//

import UIKit

class JakkulaContactViewController: UIViewController {
    
    var intials = ""
    var phonenumber = ""
    
    
    
    @IBOutlet weak var initialsOL: UILabel!
    
    
    @IBOutlet weak var phoneNumberOL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        initialsOL.text = "intilas:\(intials)"
        phoneNumberOL.text = "Phone Number: \(phonenumber)"
        print(phonenumber)
    }
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

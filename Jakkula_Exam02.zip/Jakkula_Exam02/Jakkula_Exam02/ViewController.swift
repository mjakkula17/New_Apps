//
//  ViewController.swift
//  Jakkula_Exam02
//
//  Created by Mounika Jakkula on 11/14/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var LoanTypeOL: UITextField!
    
    @IBOutlet weak var amountOL: UITextField!
    
    @IBOutlet weak var interestRateOL: UITextField!
    
    @IBOutlet weak var termOL: UITextField!
    
    var totalMonths:Double = 0.0
    var monthlyInterestRate:Double  = 0.0
    var monthlyEMIPayment:Double  = 0.0
    var imageName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CalcEMIBtn(_ sender: Any) {
        
        
        
        var term = Double(termOL.text!)
        totalMonths = (term! * 12)
        
        var interestRate = Double(interestRateOL.text!)
        monthlyInterestRate = (interestRate!/12) / 100
        
        var loanAmount = Double(amountOL.text!)
        
        monthlyEMIPayment = loanAmount! * (monthlyInterestRate * pow(1 + monthlyInterestRate,totalMonths)) / (pow(1 + monthlyInterestRate,totalMonths) - 1)
        
        var loanType:String = " "
        loanType = String(LoanTypeOL.text!)
        
        if(loanType == "Car") || (loanType == "car")
        {
            imageName = "Car"
        }
        else if(loanType == "Personal") || (loanType == "personal"){
            imageName = "Personal"
        }
        else if(loanType == "Home") || (loanType == "home"){
            imageName = "Home"
        }
    
        
    }
    
    @IBAction func resetBtn(_ sender: Any) {
        totalMonths = 0.0
        monthlyInterestRate = 0.0
        monthlyEMIPayment  = 0.0
        imageName = ""
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        if transition == "Result1"{
            
            var destination = segue.destination as! ResultViewController
            destination.term = Double(termOL.text!)!
           destination.interestRate = Double(interestRateOL.text!)!
            destination.loanType = LoanTypeOL.text!
            destination.imageName = imageName
            
            
            
            
            
        }
        
    }
    
}


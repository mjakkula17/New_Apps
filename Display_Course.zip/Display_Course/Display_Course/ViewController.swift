//
//  ViewController.swift
//  Display_Course
//
//  Created by Kagitha,Hemanth Sai on 9/28/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageDisplay: UIImageView!
    
    @IBOutlet weak var crsNumber: UILabel!
    
    @IBOutlet weak var crsName: UILabel!
    
    @IBOutlet weak var semOffered: UILabel!
    
    
    @IBOutlet weak var previousBtnOL: UIButton!
    
    @IBOutlet weak var nextBtnOL: UIButton!
    
    //create array of course details
    var courses = [["img01","44542","Network Security","Fall 2023"],
                   ["img02","44643","iOS","Fall 2023"],
                   ["img03","44555","Data Streaming","Summer 2024"]]
    
    var imageNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //disable previous button
        previousBtnOL.isEnabled=false
        
        //Display first course details
        //crsNumber.text = courses[0][1]
        //crsName.text = courses[0][2]
        //semOffered.text = courses[0][3]
        
        updateDisplay(imageNumber)
        
        //Display image
        imageDisplay.image = UIImage(named: courses[0][0])
    }
    
    @IBAction func previousBtnClicked(_ sender: Any) {
        //Enable Next button
        nextBtnOL.isEnabled = true
        
        //previous elements in courses array should be displayed
        imageNumber -= 1
        
        //call the updateDisplay() method
        updateDisplay(imageNumber)
        
        //Disable previous button for first element in arrray
        if(imageNumber == 0) {
            previousBtnOL.isEnabled = false
        }
    }
    

    //nextBtnClicked
    @IBAction func submitBtnClicked(_ sender: Any) {
        //Enable Previous button
        previousBtnOL.isEnabled = true
        
        //next element in courses array must be displayed
        imageNumber += 1
        
        //call the updateDisplay() method
        updateDisplay(imageNumber)
        
        //Disable nextbutton when reached end of coures array
        if(imageNumber == courses.count-1) {
            nextBtnOL.isEnabled = false
        }
        
    }
    //used parameter
    func updateDisplay(_ imageNumber:Int) {
        crsNumber.text = courses[imageNumber][1]
        crsName.text = courses[imageNumber][2]
        semOffered.text = courses[imageNumber][3]
        imageDisplay.image = UIImage(named: courses[imageNumber][0])
    }
    
}


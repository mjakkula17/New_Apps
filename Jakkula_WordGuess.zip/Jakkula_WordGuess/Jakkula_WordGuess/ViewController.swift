//
//  ViewController.swift
//  Jakkula_WordGuess
//
//  Created by Mounika Jakkula on 10/19/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var checkbtnclick: UIButton!
    
    @IBOutlet weak var playagainbtnclick: UIButton!
    var words = [["SWIFT","programming language"], ["CRICKET","game"],["IPHONE","Apple"],["CYCLE","Two wheeler"],["DOG","Animal"]]
    var img = ["swift.jpg","cricket.jpg","iphone.jpg","cycle.jpg","dog.jpg"]
    var count = 0
    var word = ""
    var lettersGuessed = ""
    var maximumNumbOfWrongGuesses = 10
    var maxm = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        checkbtnclick.isEnabled = false
        
        word = words[count][0]
        
        hintLabel.text = "Hint: "+words[count][1]
                
        updateUnderScore();
                
        statusLabel.isHidden = true
        
        totalWordsLabel.text! = "Total number of words in game: \(5)"
        wordsGuessedLabel.text = "Total number of words guessed successfully: \(count)"
        wordsRemainingLabel.text = "Total number of words remaining in game: \(5)"
        
    }

    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        let letter = guessLetterField.text!
                
                maxm+=1
                hintLabel.isHidden = false
                hintLabel.isEnabled = true
                lettersGuessed = lettersGuessed + letter
                guessCountLabel.isHidden =  false
                guessCountLabel.isEnabled = true
                var revealedWord = ""
                for h in word{
                    if lettersGuessed.contains(h.uppercased()){
                        revealedWord += "\(h.uppercased())"
                    }
                    else{
                        revealedWord += "_ "
                    }
                }
                guessCountLabel.text = "You have made \(maxm) guesses"
                print(guessCountLabel.text!)
                userGuessLabel.text = revealedWord
                guessLetterField.text = ""
                
                if userGuessLabel.text!.contains("_") == false{
                    playagainbtnclick.isHidden = false;
                    displayImage.image = UIImage(named: img[count])
                    guessCountLabel.text = ""
                    guessCountLabel.text = "Wow! You have made \(maxm) guesses to guess the word!"
                    print(guessCountLabel.text!)
                    count+=1
                    let remaining = words.count - count
                    wordsGuessedLabel.text = "Total number of words guessed successfully: \(count)"
                    wordsRemainingLabel.text = "Total number of words remaining in game: \(remaining)"
                    checkbtnclick.isEnabled = false;
                    count-=1
                }
                
                if(maxm == maximumNumbOfWrongGuesses){
                    guessCountLabel.text = "You have used all the available guesses, Please play again"
                    print(guessCountLabel.text!)
                    checkbtnclick.isEnabled = false
                    hintLabel.isHidden = true
                    count-=1
                    playagainbtnclick.isHidden = false
                    playagainbtnclick.isEnabled = true
                    
                }
                checkbtnclick.isEnabled = false
    }
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        maxm = 0
        count+=1
        let left = words.count - count
        userGuessLabel.isHidden = false
        userGuessLabel.isEnabled=true
        statusLabel.isHidden = true
        playagainbtnclick.isEnabled = true
        displayImage.image = UIImage()
        lettersGuessed = ""
        hintLabel.isHidden = false
        guessCountLabel.text = "You have made \(maxm) guesses"
        print(guessCountLabel.text!)
        wordsGuessedLabel.text = "Total number of words guessed successfully: \(count)"
        wordsRemainingLabel.text = "Total number of words remaining in game: \(left)"

        if count==words.count{
        statusLabel.isHidden = false
        statusLabel.text = "Congratulations, You are done, Please start over again"
        guessCountLabel.isHidden = true
        displayImage.image = UIImage(named: "alldone.jpg")
        count = -1
        userGuessLabel.isHidden = true
        hintLabel.isHidden = true
        wordsGuessedLabel.text = "Total number of words guessed successfully: 0"
        wordsRemainingLabel.text = "Total number of words remaining in game: \(words.count)"
                }
                else{
                    word = words[count][0]
                    hintLabel.text = "Hint: " + words[count][1]
                    checkbtnclick.isEnabled = true
                    updateUnderScore()
                    playagainbtnclick.isHidden = true
                }
        
    }
    
    @IBAction func guesslettertxtbox(_ sender: UITextField) {
        var textltrentr = guessLetterField.text!
                
        textltrentr = String(textltrentr.last ?? " ").trimmingCharacters(in: .whitespaces)
                
        guessLetterField.text = textltrentr
                
        if !textltrentr.isEmpty{
        checkbtnclick.isEnabled = true
        }
        else{
            checkbtnclick.isEnabled = false
            }
    }
    
    func updateUnderScore() {
        userGuessLabel.text = ""
                for letter in word{
                    userGuessLabel.text! += "_ "
                }
    }
}


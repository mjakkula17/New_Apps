//
//  TrailerViewController.swift
//  FilmFusion
//
//  Created by Mounika Jakkula on 12/4/23.
//

import UIKit
import WebKit


class TrailerViewController: UIViewController {

    
    @IBOutlet weak var mywebView: WKWebView!
    
    var selectedMovie: Movie?
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //getVideo(videoCode: "naQr0uTrH_s")
        if let videoCode = selectedMovie?.trailer {
                    getVideo(videoCode: videoCode)
        }
    }
    
    func getVideo(videoCode:String)
    {
        let url = URL(string: "https://www.youtube.com/embed/\(videoCode)")
        //let url = URL(String: "https://www.youtube.com/embed/\(videoCode)")
        mywebView.load(URLRequest(url: url!))
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

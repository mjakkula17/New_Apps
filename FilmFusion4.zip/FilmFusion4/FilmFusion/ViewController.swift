//
//  ViewController.swift
//  FilmFusion
//
//  Created by SwarupaJinne on 12/4/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var ImageViewFirst: UIImageView!
    
    
    
    @IBOutlet weak var FirstBtn: UIButton!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

